/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ChangePreventers;

/**
 *
 * @author Shirley Aragon
 */
public class DivergentChangeExample {
    // Una clase que cambia por múltiples razones diferentes.

public class FileManager {
    public void parseFile(String fileName) {
        // lógica para leer el archivo
    }

    public void saveFile(String fileName, String content) {
        // lógica para guardar archivo
    }

    public void printFile(String fileName) {
        // lógica para imprimir archivo
    }
}
}
