/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dispensables;

/**
 *
 * @author Shirley Aragon
 */
public class CommentsSmellExample {
    // Comentarios innecesarios que explican cosas obvias o malas prácticas.

public class Calculator {
    // Esta función suma dos números (← innecesario, el nombre lo dice)
    public int add(int a, int b) {
        return a + b; // aquí se hace la suma (← innecesario también)
    }
}
}
