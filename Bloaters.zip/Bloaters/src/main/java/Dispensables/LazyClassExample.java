/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dispensables;

/**
 *
 * @author Shirley Aragon
 */
public class LazyClassExample {
    // Clase que no hace lo suficiente como para justificar su existencia.

public class LoggerHelper {
    public void log(String msg) {
        System.out.println(msg);
    }

    // Esto bien podría estar en la clase que lo usa.
}
}
