/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dispensables;

/**
 *
 * @author Shirley Aragon
 */
public class DeadCodeExample {
    // Código que nunca se usa pero permanece en el sistema.

public class MathUtils {
    public int square(int x) {
        return x * x;
    }

    public int unusedMethod(int x) {
        return x + 42; // Este método no se usa en ningún lado
    }
}
}
