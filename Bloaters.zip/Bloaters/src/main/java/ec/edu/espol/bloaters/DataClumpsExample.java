/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.bloaters;

/**
 *
 * @author Shirley Aragon
 */
public class DataClumpsExample {
    // Grupos de datos que siempre se pasan juntos deberían ser una clase.

public class CustomerService {
    public void register(String name, String address, String phone) {}
    public void update(String name, String address, String phone) {}
   
}
}
