/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.bloaters;

/**
 *
 * @author 
 */
public class LongMethodExample {
    // Este método realiza demasiadas tareas y es difícil de leer o reutilizar.

public class InvoiceGenerator {
    public void generateInvoice() {
        System.out.println("Calculando impuestos...");
        System.out.println("Aplicando descuentos...");
        System.out.println("Generando PDF...");
        System.out.println("Guardando en base de datos...");
        System.out.println("Enviando correo al cliente...");
     
    }
}
}
