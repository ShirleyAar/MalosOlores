/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.bloaters;

/**
 *
 * @author Shirley Aragon
 */
public class LargeClassExample {
    // Esta clase hace demasiadas cosas y debería dividirse.

public class CustomerManager {
    public void createCustomer() {}
    public void deleteCustomer() {}
    public void sendEmail() {}
    public void generateReport() {}
    public void backupData() {}
    public void printInvoice() {}
    
}

}
